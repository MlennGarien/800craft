﻿This font was created by "DjDCH" :
http://djdch.com/
The font file in this archive was created using Fontstruct the free, online
font-building tool from FontShop International. Try Fontstruct at :
http://fontstruct.fontshop.com

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the
file "LICENSE.txt" included with this archive.
If you redistribute the font file in this archive, it must be accompanied by
all the other files from this archive, including this one.

NOTE FOR FLASH USERS:
Fontstruct fonts (fontstructions) are optimized for
Flash. If the font in this archive is a pixel font, it is best displayed at a
font-size of 8.

FONTSTRUCT:
Fontstruct is brought to you by FontShop.
Visit us at http://www.fontshop.com
FontShop is the original independent font retailer. We’ve been around since
the dawn of digital type. Whether you need the right font or need to create the
right font from scratch, let our 19 years of experience work for you.

COPYRIGHT:
Fontstruct is copyright ©2010 Fontshop FSI and Rob Meek
Fontstruct was created for FontShop International by Rob Meek
(http://www.robmeek.com).