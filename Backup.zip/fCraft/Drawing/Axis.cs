﻿// Copyright 2009, 2010, 2011, 2012 Matvei Stefarov <me@matvei.org>

namespace fCraft.Drawing {
    public enum Axis {
        X, Y, Z
    }
}