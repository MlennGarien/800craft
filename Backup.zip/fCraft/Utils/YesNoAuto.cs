﻿// Copyright 2009, 2010, 2011, 2012 Matvei Stefarov <me@matvei.org>

namespace fCraft {
    public enum YesNoAuto {
        Auto,
        Yes,
        No
    }
}