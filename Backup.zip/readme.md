## About 800craft
800craft is a modified version of the popular Minecraft server software called fCraft. It was created by Jonty800 and is now maintained by GlennMR and Jonty800.

800Craft is currently working on a big update, which will include Physics and many more new features and commands.
Something to get real excited for is the MineManager that is coming very soon. You'll be able to access your console and monitor month by month server statistics anywhere in the world from 800Craft.net. And best of all, it's going to be 100% free!
Download it now, 800Craft is extremely stable and very high on performance and when we release our next version, we'll send you an automatic update :).
## Features

On top of all the amazing features fCraft already has, we have implemented:

* Custom kick and ban commands such as: /Basscanon, /Gtfo, /Tempban, /Banx, /Warn
* Custom chat commands such as: /High5, /Away, /Poke, /Troll, /Review
* As well as the addition of Admin Chat, you also get the option to create your own chat channel
* Fun commands such as: /Slap, /Kill, /Possess
* Additional building commands
* Fly around the server with /Fly
* Voting with /Vote
* Make a server-wide vote for if a player should be kicked with /Vote kick
* Set your rank requirements with /Requirements (/Reqs)
* Change your server's blocks with /Env terrain
* Let your server's environment change according to the local time with /Env realistic
* Wipe your guest world easily with /Guestwipe
* Create dummy skins on a given world
* Minecraft making you mad? /Ragequit
* Doors
* Portals
* Realms (Personal worlds for players)
* Hide ranks with /Rhide
* Teleport to zones with /Tpzone
* Control your Realm with /Realm create activate kick ban unban like invite join flush
* Fun modes like: /Bromode
* Flying
* Anti-Caps detector
* Profanity detector
* Grass Physics (More physics coming soon)

* Customize your server by writing your own .NET DLL's and using them to modify existing functions or add features.

## HeartbeatSaver

* When you shutdown your server, or the server crashes, the Heartbeat Saver automatically opens, keeping your uptime on minecraft.net the same as it was before shutdown.
Nobody likes suddenly dropping to the bottom of a list containing 1000+ servers.

This feature can only found in 800Craft.

## Release
800Craft has been released and is currently at version 0.103. You can download it here: https://github.com/GlennMR/800craft/downloads
For support, visit our forum here: http://www.au70galaxy.com/314/upload/index.php?/forum/32-au70-server-software/

Thanks for using 800Craft, enjoy!