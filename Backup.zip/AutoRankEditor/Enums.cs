﻿namespace AutoRankEditor {
    public enum ConditionScopeType {
        Total,
        SinceRankChange,
        SinceKick
    }


    public enum ActionType {
        Suggested,
        Required,
        Automatic
    }
}
